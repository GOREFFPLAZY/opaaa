/*
 * Helper script to focus first element of type text or password
 */
$(document).ready(function() {
    $('input[type="text"], input[type="password"]').each(function() {
        if (this.value === '') {
            this.focus();
            return false;
        }
    });
});

