function token_selection (tokenName, htmlEncodedTokenStr) {
	var maxSelectSize = 8;
	var tokensStr = $('<div />').html(htmlEncodedTokenStr).text();
	var tokens = tokensStr.split(',');
	var selectSize = Math.min(tokens.length, maxSelectSize);
	var tokenSelect = '<select " name="' + tokenName + '">';
	
	for (var i in tokens) {
		var token = tokens[i].replace(/^\s\s*/, '').replace(/\s\s*$/, '');
		if (token != '') {
			tokenSelect += '<option value="' + token + '">' + token + '</option>';
		}
	}
	tokenSelect += '</select>';
	document.write(tokenSelect);
}
